# 麒麟 oline 快速启动

机器人端在已构建的 ros_ws 加载 ROS 和工作区环境；先修改
`src/robot_task_control/config/robot_task_oline.yaml` 的麒麟实际 IP，重新构建并加载安装环境。

```bash
source /opt/ros/jazzy/setup.bash
colcon build --packages-select eli_cs_robot_serial robot_task_control --executor sequential
source install/setup.bash
ros2 launch robot_task_control robot_task_oline.launch.py validate_only:=true
# 校验不是运动安全证明，确认现场就绪后再启动：
ros2 launch robot_task_control robot_task_oline.launch.py
```

麒麟解压新版 `industrial_pc_kylin_tcp.zip`，进入包目录，核对 `config.json` 中的机器人 IP 和保存目录。
开放/连通 9010、9002、9030，然后只需启动控制页面：

```bash
./start_control_page.sh
```

该脚本会启动页面服务并自动打开麒麟本机浏览器。页面进程同时启动 9010 状态与心跳、9002 海康图片接收、9030 RGB-D 接收和检测结果管理，无需再单独启动监听程序。
页面显示任务阶段、机械臂与安全状态、循迹、底盘通信、电量与充电、相机检测、各 TCP 通道、活动异常、厚度和最近检测结果。
可点“启动任务”“检测”“返回充电”“中止任务”。每轮先点“检测”完成采图，状态进入 `WAIT_RESULT` 后，再在页面填写并发送本轮XYZ相机坐标，或选择本机真实结果 JSON 文件发送检测点。
页面仅绑定本机回环地址；一次只运行一个 `control_page.py` 或 `listen_robot.py`，避免 9030 端口冲突。
无桌面环境可执行 `./start_control_page.sh --no-browser`，再在麒麟本机打开 `http://127.0.0.1:8765/`。
如只需命令行，继续使用 `python3 listen_robot.py` 常驻监听。

另一终端依次操作：

```bash
python3 start_task.py --action start
# 到站三图保存确认后 WAIT_DETECT：
python3 start_task.py --action detect
# WAIT_RESULT：发送本批真实三维点，result.json 不是包内 DEMO 文件。
python3 send_points.py --file result.json
# 本轮测完回拍照原位 WAIT_NEXT，可再发 detect：
python3 start_task.py --action detect
# 等新三图确认、WAIT_RESULT 后，发送新结果：
python3 send_points.py --file next_result.json
# WAIT_NEXT 时回家；也允许首次 WAIT_DETECT 时不测直接回家：
python3 start_task.py --action go_home
```

`python3 start_task.py --action status` 查询阶段；`--action stop` 请求中止，不自动回家。
运动中 go_home 被拒绝；重发同一指令复用 message_id，新操作使用新 ID。
不要把上述注释当固定延时，需要观察实际阶段。
详细条件、坐标报文、三图保存确认及故障字段见 [OLINE流程与协议](OLINE流程与协议.md)。
